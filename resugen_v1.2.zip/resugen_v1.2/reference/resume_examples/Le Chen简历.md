# Le Chen简历

> Converted from PDF for the resume generator reference system.

<!-- Page 1 -->

Le Chen简历

## 一句话推荐

Le Chen是Meta MGenAI，广告 Agent 方向核心骨干，负责 BizAI Ads 等高价值 Agent 场 景，过往经历覆盖搜索、Deep Research、广告优化、创意生成等完整链路；兼具模型训练、 后训练与产品落地能力，能够打通多智能体到业务应用的闭环；同时具备成熟团队管理经验， 当前在核心 Agent 方向管理约 10 人，兼具技术深度、产品 sense 和组织领导力。

## 个人基本信息

项目

内容

Le Chen

姓名

37岁

年龄

Senior Staff Software Engineer & Senior TLM

当前职位

广告Agent负责人

核心身份

LinkedIn

https://www.linkedin.com/in/le-c-bb134049
所在地

San Francisco Bay Area

## 教育背景

Northeastern University (博士)

时间：2011年 - 2017年

北京邮电大学（本科)

时间：2006年 - 2010年

## 工作经历

<!-- Page 2 -->

### Meta | Senior Staff Software Engineer & Senior Tech Lead Manager

### 2017年 - 至今

- 负责 Meta AI Search、Deep Research 和 BizAI Ads 的 Agent 与多智能体平台建设

- 构建了融合互联网级公开数据与第一方数据的搜索与深度研究 Agent，并主导 planner

model 和 response model 的后训练（SFT / RL）

- 开发了用于广告投放优化以及图片、视频创意自动生成的 Ads Agent

- 设计并实现了多智能体工作流编排引擎，目前已在公司范围内推广采用

- 负责 Core Modeling、机器学习基础设施、数据平台和推荐平台等方向，建设可扩展的机器

学习系统，推动 Messenger、Instagram 和 Facebook Blue 等产品持续创新

- 相关平台支撑 60+ 个产品、70+ 位机器学习工程师和 10+ 个跨组织团队，服务规模达

到 100 万+ QPS、300+ 个模型和 6 万个特征（相比早期的 2 万 QPS、不到 10 个模

型和 3000 个特征大幅提升）

- 主导构建端到端机器学习解决方案，覆盖 retrieval、recommendation、ranking、

feature engineering、serving/delivery、data quality monitoring 以及 model

architecture 等多个环节
